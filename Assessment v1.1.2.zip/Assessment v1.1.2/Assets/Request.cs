﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;
public class Request : MonoBehaviour {
    private const string API = "https://workbcjobs.api.gov.bc.ca/v1/jobs";

    [SerializeField]
    private Text result;
    [SerializeField]
    private Text jobs;
    [SerializeField]
    private GameObject previous;
    [SerializeField]
    private GameObject next;

    private string []data = new string [6];
    private string[] cutarray;
    private string[] jobcount;
    private bool ready = false;
    private int count;
    private int checkcutarray;
    private int bound;
    
    public void Requestapi()
    {
        WWWForm formdata = new WWWForm();
        formdata.AddField("lastRequestDate", data[0]);
        formdata.AddField("region", data[1]);
        formdata.AddField("city", data[2]);
        if(data[3] != "")
        {
            formdata.AddField("jobTypes", data[3]);
        }
        
        formdata.AddField("majorProjects", data[4]);
        if(data[5] != "")
        {
            formdata.AddField("industries", data[5]);
        }
        WWW request = new WWW(API, formdata);
        
        StartCoroutine(Upload(request));
    }

    private void Awake()
    {
        previous.SetActive(false);
        next.SetActive(false);
    }

    private void Update()
    {
        if (ready)
        {
            if (count + 1 > checkcutarray)
            {
                cutarray[count + 1] = cutarray[count + 1].Substring(0, cutarray[count + 1].Length - 2);
                checkcutarray = count + 1;
            }
            
            string[] cutonearray = cutarray[count + 1].Split(',');
            result.text = "{\"jobID";
            foreach(string s in cutonearray)
            {
                result.text = result.text + s + ",\n";
            }
            int jobpage = count + 1;
            jobs.text = "This is the job " + jobpage + " out of " + jobcount[1].Substring(0, jobcount[1].Length - 11);
            ready = false;

        }
        if(count + 1 >= bound)
        {
            next.SetActive(false);
        }

        if(count - 1 < 0)
        {
            previous.SetActive(false);
        }
    }

    private IEnumerator Upload(WWW request)
    {
        yield return request;
        string cut = request.text;
        cutarray = cut.Split(new[] { "jobID"},StringSplitOptions.None);
        foreach (string s in cutarray)
        {
            Debug.Log(s);
        }
        jobcount = cutarray[0].Split(new[] { "{\"count\":" }, StringSplitOptions.None);
        bound = int.Parse(jobcount[1].Substring(0, jobcount[1].Length - 11));
        if (bound == 0)
        {
            ready = false;
        }
        else if (bound == 1)
        {
            ready = true;
        }
        else
        {
            next.SetActive(true);
            ready = true;
        }
        
    }
    
    public void getlastRequestDate(string s)
    {
        if (s == "n" || s == "N")
        {
            data[0] = "";
        }
        else
            data[0] = s;
    }
    
    public void getRegion(string s)
    {
        if (s == "n" || s == "N")
        {
            data[1] = "";
        }
        else
            data[1] = s;
    }

    public void getCity(string s)
    {
        if (s == "n" || s == "N")
        {
            data[2] = "";
        }
        else
            data[2] = s;
    }

    public void getJobTypes(string s)
    {
        if (s == "n" || s == "N")
        {
            data[3] = "";
        }
        else
            data[3] = s;
    }

    public void getmajorProjects(string s)
    {
        if (s == "n" || s == "N")
        {
            data[4] = "";
        }
        else
            data[4] = s;
    }

    public void getindustries(string s)
    {
        if (s == "n" || s == "N")
        {
            data[5] = "";
        }
        else
            data[5] = s;
    }

    public void checkpageNext() {
        if (count + 1 < bound)
        {
            count++;
            ready = true;
            previous.SetActive(true);
        }
    }

    public void checkpageback()
    {
        if (count - 1 >= 0)
        {
            count--;
            ready = true;
            next.SetActive(true);
        }
    }

}
